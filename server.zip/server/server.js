const express = require("express")
const cors = require("cors")
const app = express()
const userRouter = require("./router/user")
const trainerRouter = require("./router/trainer")
const packageRouter = require("./router/package")
const activityRouter = require("./router/activity")


app.use(cors("*"))
app.use(express.json())
app.use(express.static("uploads"))

app.use("/user", userRouter)
app.use("/trainer", trainerRouter)
app.use("/package", packageRouter)
app.use("/activity", activityRouter)



app.listen(3000, "0.0.0.0", () => {
  console.log("Server started on port 3000")
})
