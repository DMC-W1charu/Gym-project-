CREATE TABLE users(
    id INT PRIMARY KEY AUTO_INCREMENT, 
    first_name VARCHAR(20),
    last_name VARCHAR(20),
    email VARCHAR(50) UNIQUE,
    password VARCHAR(20), 
    mobile CHAR(10));

INSERT INTO users(first_name,last_name,email,password,mobile) 
VALUES("test","test","test@gmail.com","test","1234567890");


 create table Package
     (
     packageid int primary key auto_increment,
     packagename varchar(50),
     description varchar(300),
     duration int,
     image varchar(100),
     startdate date,
     enddate date,
     amount float,
     activityid int,
     foreign key (activityid) references Activity (activityid),
     createdTimestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    
    INSERT INTO Package (packagename, description, duration, image, startdate, enddate, amount, activityid)
     VALUES ('Gold', 'gym gold package', 2, 'gold.jpg', '2024-01-01', '2024-03-01', 789.00, 1);


     create table Activity
          (
          activityid int primary key auto_increment,
         activityname varchar(50),
          description text,
          trainerid int,
          foreign key (trainerid) references Trainer (trainerid),
          image varchar(200)
     );
INSERT INTO Activity (activityname, description, trainerid, image)
     VALUES ('Aerobic', 'Aerobic is defined as "relating to, involving, or requiring oxygen", and refers to the use of oxygen to meet energy demands during exercise via aerobic...', 1, 'aerobic.webp');



create table Trainer
     (
     trainerid int primary key auto_increment,
     firstname varchar(50),
     lastname varchar(50),
     email varchar(50),
     mobileno varchar(20),
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
     );

insert into Trainer(firstname,lastname,email,mobileno)values     
    -> ('Rahul','Deshpande','rahul@gmail.com','9876543212'),
    -> ('Sunil','Koli','koli@gmail.com','7896543215'),
    -> ('Priya','Marathe','priya@gmail.com','7896964535');


create table Payment
     (
     paymentid int primary key auto_increment,
     userid int,
     amount float,
     paymentdate date,
     paymentmode varchar(50),
     foreign key(userid) references user(userid),
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
     );