const express = require('express');
const router = express.Router();
const activitiesController = require('../controllers/activitiesController');

router.get('/', activitiesController.getAllActivities);
router.get('/:activityId', activitiesController.getActivityById);
router.post('/', activitiesController.createActivity);
router.put('/:activityId', activitiesController.updateActivity);
router.delete('/:activityId', activitiesController.deleteActivity);

module.exports = router;
