const express = require('express');
const router = express.Router();
const bookingsController = require('../controllers/bookingsController');

router.get('/', bookingsController.getAllBookings);
router.get('/:bookingId', bookingsController.getBookingById);
router.post('/', bookingsController.createBooking);
router.put('/:bookingId', bookingsController.updateBooking);
router.delete('/:bookingId', bookingsController.deleteBooking);

module.exports = router;

