const express = require('express');
const router = express.Router();
const packagesController = require('../controllers/packagesController');

router.get('/', packagesController.getAllPackages);
router.get('/:packageId', packagesController.getPackageById);
router.post('/', packagesController.createPackage);
router.put('/:packageId', packagesController.updatePackage);
router.delete('/:packageId', packagesController.deletePackage);

module.exports = router;
