const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

// Create Express app
const app = express();

// Middleware
app.use(bodyParser.json());
//app.use(cors());

// Import routes
const usersRoutes = require('./routes/usersRoutes');
const trainersRoutes = require('./routes/trainersRoutes');
const packagesRoutes = require('./routes/packagesRoutes');
const activitiesRoutes = require('./routes/activitiesRoutes');
const bookingsRoutes = require('./routes/bookingsRoutes');
const paymentsRoutes = require('./routes/paymentsRoutes');
const loginsRoutes = require('./routes/loginsRoutes');

// Use routes
app.use('/users', usersRoutes);
app.use('/trainers', trainersRoutes);
app.use('/packages', packagesRoutes);
app.use('/activities', activitiesRoutes);
app.use('/bookings', bookingsRoutes);
app.use('/payments', paymentsRoutes);
app.use('/logins', loginsRoutes);

// Define a default route
app.get('/', (req, res) => {
  res.send('Welcome to the Fitness API');
});

// Start the server
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
