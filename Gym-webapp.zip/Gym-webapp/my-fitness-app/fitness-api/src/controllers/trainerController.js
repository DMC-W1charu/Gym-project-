const db = require('./db');

exports.getAllTrainers = (req, res) => {
  db.query('SELECT * FROM Trainers', (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
};

exports.getTrainerById = (req, res) => {
  const trainerId = req.params.trainerId;
  db.query('SELECT * FROM Trainers WHERE TrainerID = ?', [trainerId], (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else if (results.length === 0) {
      res.status(404).json({ error: 'Trainer not found' });
    } else {
      res.json(results[0]);
    }
  });
};

exports.createTrainer = (req, res) => {
  const newTrainer = req.body;
  db.query('INSERT INTO Trainers SET ?', [newTrainer], (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      newTrainer.TrainerID = results.insertId;
      res.status(201).json(newTrainer);
    }
  });
};

exports.updateTrainer = (req, res) => {
  const trainerId = req.params.trainerId;
  const updatedTrainer = req.body;

  db.query('UPDATE Trainers SET ? WHERE TrainerID = ?', [updatedTrainer, trainerId], (err) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(updatedTrainer);
    }
  });
};

exports.deleteTrainer = (req, res) => {
  const trainerId = req.params.trainerId;

  db.query('DELETE FROM Trainers WHERE TrainerID = ?', [trainerId], (err) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json({ message: 'Trainer deleted successfully' });
    }
  });
};