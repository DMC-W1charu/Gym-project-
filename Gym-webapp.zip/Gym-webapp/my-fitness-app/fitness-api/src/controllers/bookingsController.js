const db = require('./db');

exports.getAllBookings = (req, res) => {
  db.query('SELECT * FROM Bookings', (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
};

exports.getBookingById = (req, res) => {
  const bookingId = req.params.bookingId;
  db.query('SELECT * FROM Bookings WHERE BookingID = ?', [bookingId], (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else if (results.length === 0) {
      res.status(404).json({ error: 'Booking not found' });
    } else {
      res.json(results[0]);
    }
  });
};

exports.createBooking = (req, res) => {
  const newBooking = req.body;
  db.query('INSERT INTO Bookings SET ?', [newBooking], (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      newBooking.BookingID = results.insertId;
      res.status(201).json(newBooking);
    }
  });
};

exports.updateBooking = (req, res) => {
  const bookingId = req.params.bookingId;
  const updatedBooking = req.body;

  db.query('UPDATE Bookings SET ? WHERE BookingID = ?', [updatedBooking, bookingId], (err) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(updatedBooking);
    }
  });
};

exports.deleteBooking = (req, res) => {
  const bookingId = req.params.bookingId;

  db.query('DELETE FROM Bookings WHERE BookingID = ?', [bookingId], (err) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json({ message: 'Booking deleted successfully' });
    }
  });
};