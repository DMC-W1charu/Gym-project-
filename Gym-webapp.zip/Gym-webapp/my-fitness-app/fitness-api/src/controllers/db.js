const mysql = require('mysql2');
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Learnify@2024',
  database: 'fitness_db',
  port: 3306
});


module.exports = db;
