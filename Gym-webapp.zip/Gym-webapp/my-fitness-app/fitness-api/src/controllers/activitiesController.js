const db = require('./db');

exports.getAllActivities = (req, res) => {
  db.query('SELECT * FROM Activities', (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
};


exports.getActivityById = (req, res) => {
  const activityId = req.params.activityId;
  db.query('SELECT * FROM Activities WHERE ActivityID = ?', [activityId], (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else if (results.length === 0) {
      res.status(404).json({ error: 'Activity not found' });
    } else {
      res.json(results[0]);
    }
  });
};

exports.createActivity = (req, res) => {
  const newActivity = req.body;
  db.query('INSERT INTO Activities SET ?', [newActivity], (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      newActivity.ActivityID = results.insertId;
      res.status(201).json(newActivity);
    }
  });
};


exports.updateActivity = (req, res) => {
  const activityId = req.params.activityId;
  const updatedActivity = req.body;

  db.query('UPDATE Activities SET ? WHERE ActivityID = ?', [updatedActivity, activityId], (err) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(updatedActivity);
    }
  });
};


exports.deleteActivity = (req, res) => {
  const activityId = req.params.activityId;

  db.query('DELETE FROM Activities WHERE ActivityID = ?', [activityId], (err) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json({ message: 'Activity deleted successfully' });
    }
  });
};
