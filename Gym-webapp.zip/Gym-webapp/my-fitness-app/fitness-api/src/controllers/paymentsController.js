const db = require('./db');

exports.getAllPayments = (req, res) => {
  db.query('SELECT * FROM Payments', (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
};

exports.getPaymentById = (req, res) => {
  const paymentId = req.params.paymentId;
  db.query('SELECT * FROM Payments WHERE PaymentID = ?', [paymentId], (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else if (results.length === 0) {
      res.status(404).json({ error: 'Payment not found' });
    } else {
      res.json(results[0]);
    }
  });
};

exports.createPayment = (req, res) => {
  const newPayment = req.body;
  db.query('INSERT INTO Payments SET ?', [newPayment], (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      newPayment.PaymentID = results.insertId;
      res.status(201).json(newPayment);
    }
  });
};

exports.updatePayment = (req, res) => {
  const paymentId = req.params.paymentId;
  const updatedPayment = req.body;

  db.query('UPDATE Payments SET ? WHERE PaymentID = ?', [updatedPayment, paymentId], (err) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(updatedPayment);
    }
  });
};

exports.deletePayment = (req, res) => {
  const paymentId = req.params.paymentId;

  db.query('DELETE FROM Payments WHERE PaymentID = ?', [paymentId], (err) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json({ message: 'Payment deleted successfully' });
    }
  });
};