const db = require('./db');

exports.getAllUsers = (req, res) => {
  console.error('Request received: getAllUsers()');
  db.query('SELECT * FROM Users', (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
};

exports.getUserById = (req, res) => {
  const userID = req.params.userID;
  db.query('SELECT * FROM Users WHERE UserID = ?', [userID], (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else if (results.length === 0) {
      res.status(404).json({ error: 'User not found' });
    } else {
      res.json(results[0]);
    }
  });
};

exports.createUser = (req, res) => {
  const newUser = req.body;
  db.query('INSERT INTO Users SET ?', [newUser], (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      newUser.UserID = results.insertId;
      res.status(201).json(newUser);
    }
  });
};

exports.updateUser = (req, res) => {
  const userID = req.params.userID;
  const updatedUser = req.body;

  db.query('UPDATE Users SET ? WHERE UserID = ?', [updatedUser, userID], (err) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(updatedUser);
    }
  });
};

exports.deleteUser = (req, res) => {
  const userID = req.params.userID;

  db.query('DELETE FROM Users WHERE UserID = ?', [userID], (err) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json({ message: 'User deleted successfully' });
    }
  });
};