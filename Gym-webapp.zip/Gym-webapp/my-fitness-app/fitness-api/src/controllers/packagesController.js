const db = require('./db');

exports.getAllPackages = (req, res) => {
  db.query('SELECT * FROM Packages', (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
    }
  });
};

exports.getPackageById = (req, res) => {
  const packageId = req.params.packageId;
  db.query('SELECT * FROM Packages WHERE PackageID = ?', [packageId], (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else if (results.length === 0) {
      res.status(404).json({ error: 'Package not found' });
    } else {
      res.json(results[0]);
    }
  });
};

exports.createPackage = (req, res) => {
  const newPackage = req.body;
  db.query('INSERT INTO Packages SET ?', [newPackage], (err, results) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      newPackage.PackageID = results.insertId;
      res.status(201).json(newPackage);
    }
  });
};

exports.updatePackage = (req, res) => {
  const packageId = req.params.packageId;
  const updatedPackage = req.body;

  db.query('UPDATE Packages SET ? WHERE PackageID = ?', [updatedPackage, packageId], (err) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(updatedPackage);
    }
  });
};

exports.deletePackage = (req, res) => {
  const packageId = req.params.packageId;

  db.query('DELETE FROM Packages WHERE PackageID = ?', [packageId], (err) => {
    if (err) {
      console.error('Error executing MySQL query:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json({ message: 'Package deleted successfully' });
    }
  });
};