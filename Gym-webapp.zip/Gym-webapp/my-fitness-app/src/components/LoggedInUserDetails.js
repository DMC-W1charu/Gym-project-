import React, { useState, useEffect } from 'react';
import { Card, Table, Button } from 'react-bootstrap';
import BookingForm from './BookingForm';

const LoggedInUserDetails = ({ user }) => {
  const [userDetails, setUserDetails] = useState({});
  const [bookingDetails, setBookingDetails] = useState({});
  const [packageDetails, setPackageDetails] = useState({});
  const [trainerDetails, setTrainerDetails] = useState({});
  const [activityDetails, setActivityDetails] = useState({});
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch user details
        const userResponse = await fetch(`http://localhost:3000/users/${user.UserID}`);
        const userJson = await userResponse.json();
        setUserDetails(userJson);

        // Fetch booking details
        const bookingResponse = await fetch(`http://localhost:3000/bookings/userId/${user.UserID}`);
        const bookingJson = await bookingResponse.json();
        setBookingDetails(bookingJson);

        // Fetch package details
        const packageResponse = await fetch(`http://localhost:3000/packages/${user.UserID}`);
        const packageJson = await packageResponse.json();
        setPackageDetails(packageJson);

        // Fetch trainer details
        const trainerResponse = await fetch(`http://localhost:3000/trainers/${user.UserID}`);
        const trainerJson = await trainerResponse.json();
        setTrainerDetails(trainerJson);

        // Fetch activity details
        const activityResponse = await fetch(`http://localhost:3000/activities/${user.UserID}`);
        const activityJson = await activityResponse.json();
        setActivityDetails(activityJson);
      } catch (error) {
        setError(`Error fetching data: ${error.message}`);
      }
    };

    fetchData();
  }, [user]);

  return (
    <div className="container mt-4">
      {error && <p className="text-danger">{error}</p>}

      <div className="row">
        <div className="col-md-12 mb-4">
          <Card>
            <Card.Body>
              <Card.Title>User Details</Card.Title>
              <Table striped bordered hover responsive>
                <tbody>
                  <tr>
                    <td>User ID</td>
                    <td>{userDetails.UserID}</td>
                  </tr>
                  <tr>
                    <td>Name</td>
                    <td>{userDetails.FirstName}, {userDetails.LastName}</td>
                  </tr>
                  <tr>
                    <td>Email</td>
                    <td>{userDetails.Email}</td>
                  </tr>
                  {/* Add more user details here */}
                </tbody>
              </Table>
            </Card.Body>
          </Card>
        </div>
      </div>

      <div className="row">
        <div className="col-md-12 mb-4">
          <Card>
            <Card.Body>
              <Card.Title>Booking Details</Card.Title>
              <Table striped bordered hover responsive>
                <tbody>
                  {bookingDetails.BookingID ? (
                    <>
                      <tr>
                        <td>Booking Date</td>
                        <td>{bookingDetails.BookingDate}</td>
                      </tr>
                      <tr>
                        <td>Time Slot</td>
                        <td>{bookingDetails.TimeSlot}</td>
                      </tr>
                    </>
                  ) : (
                    <tr>
                      <td colSpan="2">
                        <BookingForm user={user} />
                      </td>
                    </tr>
                  )}
                </tbody>
              </Table>
            </Card.Body>
          </Card>
        </div>
      </div>

      <div className="row">
        <div className="col-md-12 mb-4">
          <Card>
            <Card.Body>
              <Card.Title>Package Details</Card.Title>
              <Table striped bordered hover responsive>
                <tbody>
                  <tr>
                    <td>Package ID</td>
                    <td>{packageDetails.PackageID}</td>
                  </tr>
                  <tr>
                    <td>Package Name</td>
                    <td>{packageDetails.PackageName}</td>
                  </tr>
                  <tr>
                    <td>Description</td>
                    <td>{packageDetails.Description}</td>
                  </tr>
                  {/* Add more package details here */}
                </tbody>
              </Table>
            </Card.Body>
          </Card>
        </div>
      </div>

      <div className="row">
        <div className="col-md-12 mb-4">
          <Card>
            <Card.Body>
              <Card.Title>Trainer Details</Card.Title>
              <Table striped bordered hover responsive>
                <tbody>
                  {trainerDetails.TrainerID ? (
                    <>
                      <tr>
                        <td>Trainer Name</td>
                        <td>{trainerDetails.Name}</td>
                      </tr>                      
                      <tr>
                        <td>Activity Associated</td>
                        <td>{trainerDetails.ActivityAssociated}</td>
                      </tr>
                      {/* Add more booking details here */}
                    </>
                  ) : (
                    <tr>
                      <td colSpan="2">
                        <BookingForm user={user} />
                      </td>
                    </tr>
                  )}
                </tbody>
              </Table>
            </Card.Body>
          </Card>
        </div>
      </div>

     

      {/* Add more similar structures for other details like Trainer, Activity, etc. */}
    </div>
  );
};

export default LoggedInUserDetails;
