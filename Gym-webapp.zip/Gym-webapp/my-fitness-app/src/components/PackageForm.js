import React, { useState, useEffect } from 'react';
import { Table, Form, Button, Modal, Col } from 'react-bootstrap';

const PackageForm = () => {
  const [packages, setPackages] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [newPackage, setNewPackage] = useState({
    packageName: '',
    description: '',
    amount: '',
  });

  const [editPackage, setEditPackage] = useState(null);

  useEffect(() => {
    const fetchPackages = async () => {
      try {
        const response = await fetch('http://localhost:3000/packages');
        const packagesData = await response.json();
        setPackages(packagesData);
      } catch (error) {
        console.error('Error fetching packages:', error);
      }
    };

    fetchPackages();
  }, []);

  const handleShowModal = () => {
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditPackage(null);
    setNewPackage({
      packageName: '',
      description: '',
      amount: '',
    });
  };

  const handleChange = (e) => {
    setNewPackage({
      ...newPackage,
      [e.target.name]: e.target.value,
    });
  };

  const handleEditPackage = (packageID) => {
    const packageToEdit = packages.find((packageItem) => packageItem.PackageID === packageID);
    setEditPackage(packageToEdit);
    setNewPackage({
      packageName: packageToEdit.PackageName,
      description: packageToEdit.Description,
      amount: packageToEdit.amount,
    });
    setShowModal(true);
  };

  const handleDeletePackage = async (packageID) => {
    try {
      const response = await fetch(`http://localhost:3000/packages/${packageID}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        // Refresh the packages list after deleting a package
        const updatedPackages = await response.json();
        setPackages(updatedPackages);
      } else {
        console.error('Failed to delete package');
      }
    } catch (error) {
      console.error('Error deleting package:', error);
    }
  };

  const handleAddOrUpdatePackage = async () => {
    try {
      let response;
      if (editPackage) {
        // Update existing package
        response = await fetch(`http://localhost:3000/packages/${editPackage.PackageID}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(newPackage),
        });
      } else {
        // Add new package
        response = await fetch('http://localhost:3000/packages', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(newPackage),
        });
      }
  
      if (response.ok) {
        // Refresh the packages list after adding/updating a package
        const updatedPackages = await fetch('http://localhost:3000/packages').then(res => res.json());
        setPackages(updatedPackages);
        setShowModal(false);
      } else {
        console.error('Failed to add/update package');
      }
    } catch (error) {
      console.error('Error adding/updating package:', error);
    }
  };
  

  return (
    <>
      <Button variant="primary" onClick={handleShowModal}>
        Add New Package
      </Button>

      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>{editPackage ? 'Edit Package' : 'Add New Package'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="packageName">
              <Form.Label>Package Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter package name"
                name="packageName"
                value={newPackage.packageName}
                onChange={handleChange}
              />
            </Form.Group>
            <Form.Group controlId="description">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                placeholder="Enter package description"
                name="description"
                value={newPackage.description}
                onChange={handleChange}
              />
            </Form.Group>
            <Form.Group controlId="amount">
              <Form.Label>Price</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter package amount"
                name="amount"
                value={newPackage.amount}
                onChange={handleChange}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
          <Button variant="primary" onClick={handleAddOrUpdatePackage}>
            {editPackage ? 'Update Package' : 'Add Package'}
          </Button>
        </Modal.Footer>
      </Modal>

      <Table className="mt-3" striped bordered hover>
        <thead>
          <tr>
            <th>Package ID</th>
            <th>Package Name</th>
            <th>Description</th>
            <th>Amount</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {packages.map((packageItem) => (
            <tr key={packageItem.PackageID}>
              <td>{packageItem.PackageID}</td>
              <td>{packageItem.PackageName}</td>
              <td>{packageItem.Description}</td>
              <td>{packageItem.amount}</td>
              <td>
                <Button variant="info" onClick={() => handleEditPackage(packageItem.PackageID)}>
                  Edit
                </Button>
                <Button variant="danger" onClick={() => handleDeletePackage(packageItem.PackageID)}>
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </>
  );
};

export default PackageForm;
