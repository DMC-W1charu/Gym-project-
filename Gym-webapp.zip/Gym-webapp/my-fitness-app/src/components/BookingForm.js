import React, { useState, useEffect } from 'react';
import { Form, Button, Alert } from 'react-bootstrap';

const BookingForm = ({ user }) => {
  const [bookingData, setBookingData] = useState({
    packageID: '',
    trainerID: '',
    bookingDate: '',
    timeSlot: '',
  });

  const [packages, setPackages] = useState([]);
  const [trainers, setTrainers] = useState([]);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    // Fetch packages and trainers when the component mounts
     console.log('user:', user);
    const fetchPackagesAndTrainers = async () => {
      try {
        const packagesResponse = await fetch('http://localhost:3000/packages');
        const trainersResponse = await fetch('http://localhost:3000/trainers');

        if (packagesResponse.ok && trainersResponse.ok) {
          const packagesData = await packagesResponse.json();
          const trainersData = await trainersResponse.json();

          setPackages(packagesData);
          setTrainers(trainersData);
        } else {
          console.error('Failed to fetch packages or trainers');
        }
      } catch (error) {
        console.error('Error during packages and trainers fetching:', error);
      }
    };

    fetchPackagesAndTrainers();
  }, [user]); // Empty dependency array ensures the effect runs only once on mount

  const handleChange = (e) => {
    setBookingData({
      ...bookingData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Add validation logic here if needed

    try {
      console.log('user:', user);
      console.log('Booking confirmed:', bookingData);
      const response = await fetch('http://localhost:3000/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...bookingData,
          userID: user.UserID,
        }),
      });

      if (response.ok) {
        setSuccessMessage('Booking confirmed successfully');
        setErrorMessage('');
        console.log('Booking confirmed:', bookingData);
        // Optionally, reset the form or perform any other actions after successful booking
      } else {
        setErrorMessage('Failed to confirm booking');
        setSuccessMessage('');
        console.error('Failed to confirm booking:', bookingData);
      }
    } catch (error) {
      setErrorMessage(`Error during booking confirmation: ${error.message}`);
      setSuccessMessage('');
      console.error('Error during booking confirmation:', error);
    }
  };

  return (
    <Form onSubmit={handleSubmit}>
      <Form.Group controlId="packageID">
        <Form.Label>Select Fitness Package</Form.Label>
        <Form.Control
          as="select"
          name="packageID"
          value={bookingData.packageID}
          onChange={handleChange}
          required
        >
          <option value="">Select Package</option>
          {packages.map((packageItem) => (
            <option key={packageItem.PackageID} value={packageItem.PackageID}>
              {packageItem.PackageName}
            </option>
          ))}
        </Form.Control>
      </Form.Group>

      <Form.Group controlId="trainerID">
        <Form.Label>Select Trainer</Form.Label>
        <Form.Control
          as="select"
          name="trainerID"
          value={bookingData.trainerID}
          onChange={handleChange}
          required
        >
          <option value="">Select Trainer</option>
          {trainers.map((trainer) => (
            <option key={trainer.TrainerID} value={trainer.TrainerID}>
              {trainer.Name}
            </option>
          ))}
        </Form.Control>
      </Form.Group>

      <Form.Group controlId="bookingDate">
        <Form.Label>Booking Date</Form.Label>
        <Form.Control
          type="date"
          name="bookingDate"
          value={bookingData.bookingDate}
          onChange={handleChange}
          required
        />
      </Form.Group>

      <Form.Group controlId="timeSlot">
        <Form.Label>Time Slot</Form.Label>
        <Form.Control
          type="time"
          name="timeSlot"
          value={bookingData.timeSlot}
          onChange={handleChange}
          required
        />
      </Form.Group>

      {errorMessage && <Alert variant="danger">{errorMessage}</Alert>}
      {successMessage && <Alert variant="success">{successMessage}</Alert>}

      <Button variant="primary" type="submit">
        Confirm Booking
      </Button>
    </Form>
  );
};


export default BookingForm;
