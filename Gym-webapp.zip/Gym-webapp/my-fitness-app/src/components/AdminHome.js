import React, { useState } from "react";
import {
  Form,
  Button,
  Container,
  Row,
  Col,
  Card,
  ListGroup,
  ListGroupItem,
  Table,
} from "react-bootstrap";
import UserForm from "./UserForm";

const AdminHome = () => {
  const [email, setEmail] = useState("");
  const [searchedUser, setSearchedUser] = useState(null);

  const handleSearch = async () => {
    try {
      console.error(
        "Error searching for user:",
        `http://localhost:3000/users/search/${email}`
      );
      const response = await fetch(
        `http://localhost:3000/users/search/${email}`
      );
      const user = await response.json();
      console.info("user:", user);
      if (user) {
        setSearchedUser(user);
      } else {
        setSearchedUser(null);
      }
    } catch (error) {
      console.error("Error searching for user:", error);
    }
  };

  return (
    <Container className="mt-4">
      <h2>Admin Home</h2>

      <Row className="mt-3">
        <Col md={4}>
          {/* User form */}          
          <UserForm />
        </Col>
      </Row>
    </Container>
  );
};

export default AdminHome;
