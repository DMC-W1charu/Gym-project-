import React, { useState } from 'react';
import { Form, Button, Alert } from 'react-bootstrap';

const RegistrationForm = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    contactNumber: '',
    address: '',
    email: '',
    password: '',
   // confirmPassword: '',
   // termsChecked: false,
  });

  const [showPassword, setShowPassword] = useState(false);
  //const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleCheckboxChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.checked,
    });
  };

  const handleShowPassword = (field) => {
    if (field === 'password') {
      setShowPassword(!showPassword);
    } else if (field === 'confirmPassword') {
      //setShowConfirmPassword(!showConfirmPassword);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Add validation logic here (e.g., email format, password strength, etc.)
    /*
    if (!formData.termsChecked) {
      setErrorMessage('Please accept the terms and conditions.');
      return;
    }
    */
   
    try {
      const response = await fetch('http://localhost:3000/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setSuccessMessage('Registration successful');
        setErrorMessage('');
        // Reset the form after successful registration
        setFormData({
          firstName: '',
          lastName: '',
          contactNumber: '',
          address: '',
          email: '',
          password: '',
          //confirmPassword: '',
          //termsChecked: false,
        });
      } else {
        setErrorMessage('Registration failed');
        setSuccessMessage('');
      }
    } catch (error) {
      setErrorMessage(`Error during registration: ${error.message}`);
      setSuccessMessage('');
    }
  };

  const handleReset = () => {
    setFormData({
      firstName: '',
      lastName: '',
      contactNumber: '',
      address: '',
      email: '',
      password: '',
      //confirmPassword: '',
      //termsChecked: false,
    });
    setSuccessMessage('');
    setErrorMessage('');
  };

  /*
  FirstName VARCHAR(250),
    LastName VARCHAR(250),
    ContactNumber VARCHAR(20),
    Address VARCHAR(250),
    Email VARCHAR(50) UNIQUE,
    Password VARCHAR(250),
    Status VARCHAR(50),
  */
  return (
    <Form onSubmit={handleSubmit}>
      <Form.Group controlId="firstName">
        <Form.Label>First Name</Form.Label>
        <Form.Control
          type="text"
          name="firstName"
          value={formData.firstName}
          onChange={handleChange}
          required
        />
      </Form.Group>

      <Form.Group controlId="lastName">
        <Form.Label>Last Name</Form.Label>
        <Form.Control
          type="text"
          name="lastName"
          value={formData.lastName}
          onChange={handleChange}
          required
        />
      </Form.Group>

      <Form.Group controlId="contactNumber">
        <Form.Label>Contact Number</Form.Label>
        <Form.Control
          type="text"
          name="contactNumber"
          value={formData.contactNumber}
          onChange={handleChange}
          required
        />
      </Form.Group>

      <Form.Group controlId="address">
        <Form.Label>Address</Form.Label>
        <Form.Control
          type="text"
          name="address"
          value={formData.address}
          onChange={handleChange}
          required
        />
      </Form.Group>

      <Form.Group controlId="email">
        <Form.Label>Email</Form.Label>
        <Form.Control
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          required
        />
      </Form.Group>

      {/* Repeat similar Form.Group for other fields */}

      <Form.Group controlId="password">
        <Form.Label>Password</Form.Label>
        <Form.Control
          type={showPassword ? 'text' : 'password'}
          name="password"
          value={formData.password}
          onChange={handleChange}
          required
        />
        <Form.Check
          type="checkbox"
          label="Show Password"
          onChange={() => handleShowPassword('password')}
        />
      </Form.Group>

      {errorMessage && <Alert variant="danger">{errorMessage}</Alert>}
      {successMessage && <Alert variant="success">{successMessage}</Alert>}

      <Button variant="primary" type="submit">
        Sign Up
      </Button>
      <Button variant="secondary" type="button" onClick={handleReset}>
        Reset
      </Button>
    </Form>
  );
};

export default RegistrationForm;
