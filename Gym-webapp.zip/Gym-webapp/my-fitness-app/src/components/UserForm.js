import React, { useState, useEffect } from 'react';
import { Table, Form, Button, Modal } from 'react-bootstrap';
import AdminBookingForm from './AdminBookingForm';

const UserForm = () => {
  const [users, setUsers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [showEditBookingModal, setShowEditBookingModal] = useState(false);
  const [newUser, setNewUser] = useState({
    FirstName: '',
    LastName: '',
    ContactNumber: '',
    Address: '',
    Email: '',
    Password: '',
  });

  const [editUser, setEditUser] = useState(null);
  const [bookingDetails, setBookingDetails] = useState(null);
  const [editBookingDetails, setEditBookingDetails] = useState(null);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch('http://localhost:3000/users');
        const usersData = await response.json();
        console.info("Users: " , usersData);
        setUsers(usersData);
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    };

    fetchUsers();
  }, []);

  const handleShowModal = () => {
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditUser(null);
    setNewUser({
      FirstName: '',
      LastName: '',
      ContactNumber: '',
      Address: '',
      Email: '',
      Password: '',
    });
  };

  const handleChange = (e) => {
    setNewUser({
      ...newUser,
      [e.target.name]: e.target.value,
    });
  };

  const handleEditUser = (userID) => {
    const userToEdit = users.find((user) => user.UserID === userID);
    setEditUser(userToEdit);
    setNewUser({
      FirstName: userToEdit.FirstName,
      LastName: userToEdit.LastName,
      ContactNumber: userToEdit.ContactNumber,
      Address: userToEdit.Address,
      Email: userToEdit.Email,
      Password: userToEdit.Password,
    });
    setShowModal(true);
  };

  const handleDeleteUser = async (userID) => {
    try {
      const response = await fetch(`http://localhost:3000/users/${userID}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        // Refresh the users list after deleting a user
        const updatedUsers = await response.json();
        setUsers(updatedUsers);
      } else {
        console.error('Failed to delete user');
      }
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };

  const handleViewBooking = async (userID) => {
    try {
      // Fetch booking details for the user
      const bookingResponse = await fetch(`http://localhost:3000/bookings/userId/${userID}`);
  
      if (bookingResponse.ok) {
        const bookingDetails = await bookingResponse.json();
  
        // Display booking details in a modal or popup
        console.log('Booking Details:', bookingDetails);
  
        // You can use state to manage the visibility of the modal or popup
        // For example, set a state variable like showBookingModal to true
        // and pass the bookingDetails to the modal component
        setShowBookingModal(true);
        setBookingDetails(bookingDetails);
      } else {
        console.error('Failed to fetch booking details');
      }
    } catch (error) {
      console.error('Error fetching booking details:', error);
    }
  };

  const handleCloseBookingModal = () => {
    setShowBookingModal(false);
    setBookingDetails(null);
  };

  const handleEditBooking = async (userID) => {
    try {
      // Fetch booking details for the user
      const bookingResponse = await fetch(`http://localhost:3000/bookings/userId/${userID}`);
  
      if (bookingResponse.ok) {
        const editBookingDetails = await bookingResponse.json();
  
        // Display editable booking details in a modal
        setShowEditBookingModal(true);
        setEditBookingDetails(editBookingDetails);
      } else {
        console.error('Failed to fetch booking details for editing');
      }
    } catch (error) {
      console.error('Error fetching booking details for editing:', error);
    }
  };

  const handleCloseEditBookingModal = () => {
    setShowEditBookingModal(false);
    setEditBookingDetails(null);
  };

  const handleDeleteBooking = (userID) => {
    // Implement the logic for deleting user's booking
    console.log(`Delete Booking for user with ID ${userID}`);
  };

  const handleAddOrUpdateUser = async () => {
    try {
      let response;
      if (editUser) {
        // Update existing user
        console.info("Update existing user");
        response = await fetch(`http://localhost:3000/users/${editUser.UserID}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(newUser),
        });

        console.info("Update existing user: ", response);
      } else {
        // Add new user
        response = await fetch('http://localhost:3000/users', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(newUser),
        });
      }

      if (response.ok) {
        // Refresh the users list after adding/updating a user
        console.error('Updated user');

        const updatedUsers = async () => {
            try {
              const response = await fetch('http://localhost:3000/users');
              const usersData = await response.json();
              console.info("Users: " , usersData);
              setUsers(usersData);
            } catch (error) {
              console.error('Error fetching users:', error);
            }
          };

          updatedUsers();
          setShowModal(false);
      } else {
        console.error('Failed to update user');
      }
    } catch (error) {
      console.error('Error updating user:', error);
    }
  };

  const handleEditBookingSubmit = async () => {
    try {
      // Implement the logic for updating the booking details
      console.log('Update Booking Details:', editBookingDetails);
  
      // After updating, close the modal
      setShowEditBookingModal(false);
      setEditBookingDetails(null);
    } catch (error) {
      console.error('Error updating booking details:', error);
    }
  };

  return (
    <>
      <Modal show={showModal} onHide={handleCloseModal}>        
        <Modal.Body>
          <Form>
            <Form.Group controlId="FirstName">
              <Form.Label>First Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter first name"
                name="FirstName"
                value={newUser.FirstName}
                onChange={handleChange}
              />
            </Form.Group>
            <Form.Group controlId="LastName">
              <Form.Label>Last Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter last name"
                name="LastName"
                value={newUser.LastName}
                onChange={handleChange}
              />
            </Form.Group>
            <Form.Group controlId="ContactNumber">
              <Form.Label>Contact Number</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter contact number"
                name="ContactNumber"
                value={newUser.ContactNumber}
                onChange={handleChange}
              />
            </Form.Group>
            <Form.Group controlId="Address">
              <Form.Label>Address</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                placeholder="Enter address"
                name="Address"
                value={newUser.Address}
                onChange={handleChange}
              />
            </Form.Group>
            <Form.Group controlId="Email">
              <Form.Label>Email</Form.Label>
              <Form.Control
                type="email"
                placeholder="Enter email"
                name="Email"
                value={newUser.Email}
                onChange={handleChange}
              />
            </Form.Group>
            <Form.Group controlId="Password">
              <Form.Label>Password</Form.Label>
              <Form.Control
                type="password"
                placeholder="Enter password"
                name="Password"
                value={newUser.Password}
                onChange={handleChange}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
          <Button variant="primary" onClick={handleAddOrUpdateUser}>
            {editUser ? 'Update User' : 'Add User'}
          </Button>
        </Modal.Footer>
      </Modal>

      <div className="container mt-4">
      <div className="col-md-12">
      <Table class="table">
        <thead>
          <tr>
            <th class="text-nowrap">User ID</th>
            <th class="text-nowrap">First Name</th>            
            <th class="text-nowrap">Last Name</th>
            <th class="text-nowrap">Contact Number</th>
            <th class="text-nowrap">Email</th>
            <th class="text-nowrap">Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.UserID}>
              <td>{user.UserID}</td>
              <td>{user.FirstName}</td>
              <td>{user.LastName}</td>
              <td>{user.ContactNumber}</td>
              <td>{user.Email}</td>
              <td className="row">
                <Button  className="mb-2" variant="info" onClick={() => handleEditUser(user.UserID)}>
                  Edit
                </Button>
                <Button className="mb-2" variant="danger" onClick={() => handleDeleteUser(user.UserID)}>
                  Delete
                </Button>
                <Button className="mb-2" variant="success" onClick={() => handleViewBooking(user.UserID)}>
                  View Booking
                </Button>
                <Button className="mb-2" variant="warning" onClick={() => handleEditBooking(user.UserID)}>
                  Edit Booking
                </Button>
                <Button className="mb-2" variant="danger" onClick={() => handleDeleteBooking(user.UserID)}>
                  Delete Booking
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
      </div>
      </div>      
      {/* Booking Details Modal */}
      <Modal show={showBookingModal} onHide={handleCloseBookingModal}>
        <Modal.Header closeButton>
          <Modal.Title>Booking Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {bookingDetails && (
            <>
            <h5>Booking Details</h5>
              <p>Package ID: {bookingDetails.PackageID}</p>
              <p>Trainer ID: {bookingDetails.TrainerID}</p>
              <p>Booking Date: {bookingDetails.BookingDate}</p>
              <p>Time Slot: {bookingDetails.TimeSlot}</p>
              {/* Add more booking details as needed */}
            </>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseBookingModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Edit Booking Modal */}
      <Modal show={showEditBookingModal} onHide={handleCloseEditBookingModal}>
        <Modal.Header closeButton>
          <Modal.Title>Edit Booking</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {editBookingDetails && (
            <AdminBookingForm
              // Pass necessary props to the BookingForm for editing
              initialValues={editBookingDetails}
              onSubmit={handleEditBookingSubmit}
            />
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseEditBookingModal}>
            Close
          </Button>          
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default UserForm
