import React, { useState } from 'react';
import { Form, Button, Alert } from 'react-bootstrap';

  const LoginForm = ({ onLogin }) => {
  const [formData, setFormData] = useState({
    type: 'User',
    email: '',
    password: '',
  });

  const [showPassword, setShowPassword] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('http://localhost:3000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const user = await response.json();
        setSuccessMessage('Login successful');
        setErrorMessage('');
        onLogin(user);

        // Reset the form after successful login
        setFormData({
          type: 'User',
          email: '',
          password: '',
        });
      } else {
        setErrorMessage('Login failed');
        setSuccessMessage('');
      }
    } catch (error) {
      setErrorMessage(`Error during login: ${error.message}`);
      setSuccessMessage('');
    }
  };

  return (
    <Form onSubmit={handleSubmit}>
      <Form.Group controlId="type">
        <Form.Label>User Type</Form.Label>
        <Form.Control
          as="select"
          name="type"
          value={formData.type}
          onChange={handleChange}
        >
          <option value="User">User</option>
          <option value="Admin">Admin</option>
        </Form.Control>
      </Form.Group>

      <Form.Group controlId="email">
        <Form.Label>Email</Form.Label>
        <Form.Control
          type="text"
          name="email"
          value={formData.email}
          onChange={handleChange}
          required
        />
      </Form.Group>

      <Form.Group controlId="password">
        <Form.Label>Password</Form.Label>
        <Form.Control
          type={showPassword ? 'text' : 'password'}
          name="password"
          value={formData.password}
          onChange={handleChange}
          required
        />
        <Form.Check
          type="checkbox"
          label="Show Password"
          onChange={handleShowPassword}
        />
      </Form.Group>

      {errorMessage && <Alert variant="danger">{errorMessage}</Alert>}
      {successMessage && <Alert variant="success">{successMessage}</Alert>}

      <Button variant="primary" type="submit">
        Sign In
      </Button>
    </Form>
  );
};

export default LoginForm;
