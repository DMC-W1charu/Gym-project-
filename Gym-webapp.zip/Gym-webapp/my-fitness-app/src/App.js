import React, { useState, useEffect } from 'react';
import RegistrationForm from './components/RegistrationForm';
import LoginForm from './components/LoginForm';
import LoggedInUserDetails from './components/LoggedInUserDetails';
import { Button, Col, Container, Row } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import AdminHome from './components/AdminHome';

function App() {
  const [user, setUser] = useState(null);

  const handleLogin = (loggedInUser) => {
    setUser(loggedInUser);
  };

  const handleSignOff = () => {
    setUser(null);
  };

  useEffect(() => {
    const fetchBookingStatus = async () => {
      try {
        const response = await fetch(`http://localhost:3000/bookings/${user.UserID}`);
        const bookingData = await response.json();
      } catch (error) {
        console.error('Error fetching booking status:', error);
      }
    };

    if (user) {
      fetchBookingStatus();
    }
  }, [user]);

  return (
    <Container>
      <h1 className="justify-content-center mt-4">Fitness Application</h1>
      {!user ? (
        <Row className="justify-content-center">
          <Col md={4}>
            <h2>Sign Up</h2>
            <RegistrationForm />
          </Col>

          <Col md={4}>
            <h2>Sign In</h2>
            <LoginForm onLogin={handleLogin} />
          </Col>
        </Row>
      ) : (
        <div>
          <Row className="justify-content-between mt-3">
            <Col>
              <h3>Welcome, {user.FirstName}!</h3>
            </Col>
            <Col md="auto">
              <Button variant="danger" onClick={handleSignOff}>
                Sign Off
              </Button>
            </Col>
          </Row>

          {user.UserRole ==="user" ? (
            <LoggedInUserDetails user={user} />
          ) : (
            <AdminHome user={user} />            
          )}
          
        </div>
      )}
    </Container>
  );
}

export default App;
